﻿namespace SwEngHomework.DescriptiveStatistics
{
    public class Stats
    {
        public double Average { get; set; }
        public double Median { get; set; }
        public double Range { get; set; }
    }
}
