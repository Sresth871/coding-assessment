﻿namespace SwEngHomework.DescriptiveStatistics
{
    public interface IStatsCalculator
    {
        Stats Calculate(string semicolonDelimitedContributions);
    }
}
