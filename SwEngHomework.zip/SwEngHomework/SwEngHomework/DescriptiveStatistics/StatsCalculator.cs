﻿namespace SwEngHomework.DescriptiveStatistics
{
    public class StatsCalculator : IStatsCalculator
    {
        public Stats Calculate(string semicolonDelimitedContributions)
        {
            var contributions = ParseContributions(semicolonDelimitedContributions);
            if (contributions.Count == 0)
            {
                return new Stats { Average = 0, Median = 0, Range = 0 };
            }

            var sortedContributions = contributions.OrderBy(c => c).ToList();
            var average = contributions.Average();
            var median = CalculateMedian(sortedContributions);
            var range = sortedContributions.Last() - sortedContributions.First();

            return new Stats { Average = Math.Round(average, 2), Median = Math.Round(median, 2), Range = Math.Round(range, 2) };
        }

        private List<double> ParseContributions(string semicolonDelimitedContributions)
        {
            var contributions = new List<double>();
            var tokens = semicolonDelimitedContributions.Split(';');

            foreach (var token in tokens)
            {
                if (double.TryParse(token.Trim().Replace("$", "").Replace(",", ""), out double contribution))
                {
                    contributions.Add(contribution);
                }
            }

            return contributions;
        }

        private double CalculateMedian(List<double> sortedContributions)
        {
            var count = sortedContributions.Count;
            if (count % 2 == 0)
            {
                var middleIndex1 = count / 2 - 1;
                var middleIndex2 = count / 2;
                return (sortedContributions[middleIndex1] + sortedContributions[middleIndex2]) / 2;
            }
            else
            {
                var middleIndex = count / 2;
                return sortedContributions[middleIndex];
            }
        }
    }

}
