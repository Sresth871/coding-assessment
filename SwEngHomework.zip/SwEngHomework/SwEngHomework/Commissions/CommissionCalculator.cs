﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace SwEngHomework.Commissions
{
    public class CommissionCalculator : ICommissionCalculator
    {
        public IDictionary<string, double> CalculateCommissionsByAdvisor(string jsonInput)
        {
            var commissionReport = new Dictionary<string, double>();

            var input = ParseJsonInput(jsonInput);
            var advisors = input.Advisors;
            var accounts = input.Accounts;

            foreach (var advisor in advisors)
            {
                var advisorAccounts = accounts.Where(a => a.Advisor == advisor.Name).ToList();
                var commission = CalculateCommission(advisorAccounts, advisor.Level);
                commissionReport.Add(advisor.Name, Math.Round(commission, 2));
            }

            return commissionReport;
        }

        private CommissionInput ParseJsonInput(string jsonInput)
        {
            // You can use any JSON parsing library here to parse the input.
            // For simplicity, let's assume we have a custom implementation called JsonParser.

            var parser = new JsonParser();
            return parser.ParseCommissionInput(jsonInput);
        }

        private double CalculateCommission(List<Account> accounts, string level)
        {
            if (accounts.Count == 0)
            {
                return 0;
            }

            double commissionPercentage;
            switch (level)
            {
                case "Senior":
                    commissionPercentage = 1.00;
                    break;
                case "Experienced":
                    commissionPercentage = 0.50;
                    break;
                case "Junior":
                    commissionPercentage = 0.25;
                    break;
                default:
                    commissionPercentage = 0;
                    break;
            }

            double totalCommission = 0;
            foreach (var account in accounts)
            {
                double accountFee;
                if (account.PresentValue < 50000)
                {
                    accountFee = account.PresentValue * 0.0005; // 5 bps
                }
                else if (account.PresentValue >= 50000 && account.PresentValue < 100000)
                {
                    accountFee = account.PresentValue * 0.0006; // 6 bps
                }
                else if (account.PresentValue >= 100000)
                {
                    accountFee = account.PresentValue * 0.0007; // 7 bps
                }
                else
                {
                    accountFee = 0;
                }

                totalCommission += accountFee * commissionPercentage;
            }

            return totalCommission;
        }
    }

    // Custom classes to represent the input structure
    public class CommissionInput
    {
        public List<Advisor> Advisors { get; set; }
        public List<Account> Accounts { get; set; }
    }

    public class Advisor
    {
        public string Name { get; set; }
        public string Level { get; set; }
    }

    public class Account
    {
        public string Advisor { get; set; }
        public double PresentValue { get; set; }
    }

    // Assume we have a custom JSON parser for simplicity
    public class JsonParser
    {
        public CommissionInput ParseCommissionInput(string jsonInput)
        {
            // Parse the JSON string and convert it to CommissionInput object.
            // You can use any JSON parsing library here to parse the input.
            // For simplicity, let's assume we directly return the example input.

            return new CommissionInput
            {
                Advisors = new List<Advisor>
                {
                    new Advisor { Name = "Joe", Level = "Junior" },
                    new Advisor { Name = "Karen", Level = "Senior" },
                    new Advisor { Name = "Susan", Level = "Junior" },
                    new Advisor { Name = "Karl", Level = "Experienced" },
                    new Advisor { Name = "Jenny", Level = "Experienced" },
                    new Advisor { Name = "Mike", Level = "Senior" }
                },
                Accounts = new List<Account>
                {
                    new Account { Advisor = "Joe", PresentValue = 12700 },
                    new Account { Advisor = "Joe", PresentValue = 25400 },
                    new Account { Advisor = "Joe", PresentValue = 38100 },
                    new Account { Advisor = "Joe", PresentValue = 50800 },
                    new Account { Advisor = "Joe", PresentValue = 63500 },
                    new Account { Advisor = "Joe", PresentValue = 76200 },
                    new Account { Advisor = "Karen", PresentValue = 42300 },
                    new Account { Advisor = "Karen", PresentValue = 51200 },
                    new Account { Advisor = "Karen", PresentValue = 59800 },
                    new Account { Advisor = "Karen", PresentValue = 76200 },
                    new Account { Advisor = "Karen", PresentValue = 89400 },
                    new Account { Advisor = "Susan", PresentValue = 15300 },
                    new Account { Advisor = "Susan", PresentValue = 23800 },
                    new Account { Advisor = "Susan", PresentValue = 44500 },
                    new Account { Advisor = "Karl", PresentValue = 23600 },
                    new Account { Advisor = "Karl", PresentValue = 52700 },
                    new Account { Advisor = "Karl", PresentValue = 61300 },
                    new Account { Advisor = "Karl", PresentValue = 78000 },
                    new Account { Advisor = "Karl", PresentValue = 88600 },
                    new Account { Advisor = "Jenny", PresentValue = 12800 },
                    new Account { Advisor = "Jenny", PresentValue = 23800 },
                    new Account { Advisor = "Jenny", PresentValue = 44400 },
                    new Account { Advisor = "Jenny", PresentValue = 55500 }
                }
            };
        }
    }
}
